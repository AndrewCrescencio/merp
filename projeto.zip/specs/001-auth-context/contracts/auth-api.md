# Auth API Contracts

Base path: `/api/auth`

All endpoints follow consistent error format:

```json
{ "error": "snake_case_code", "message": "Human-readable message" }
```

Error codes: `validation_error`, `conflict` (409), `unauthorized` (401), `session_expired` (401), `rate_limit_exceeded` (429), `service_unavailable` (503), `upstream_timeout` (503), `auth_unavailable` (503), `internal_error` (500)

---

## POST /api/auth/register

Register a new user account.

**Request Body**:

```json
{
  "email": "user@example.com",
  "password": "secure-password-123",
  "name": "User Name (optional)"
}
```

**Success Response**: `201 Created`

```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "User Name",
  "createdAt": "2026-06-12T00:00:00Z"
}
```

**Note**: Registration does NOT create a session per FR-001.

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Invalid email format / password too short |
| 429 | rate_limit_exceeded | Rate limit per email exceeded |
| 503 | service_unavailable | Database unreachable |

**Note (AUD-03)**: if the email is already registered, the endpoint returns the same generic `201 Created` response (id/name/createdAt derived from the request input) — no `409 conflict`, no observable difference between new and existing emails (anti-enumeration). No duplicate account is created and the existing account is never modified.

---

## POST /api/auth/login

Authenticate with email and password. Creates a session (FR-005).

**Request Body**:

```json
{
  "email": "user@example.com",
  "password": "secure-password-123",
  "rememberMe": false
}
```

**Success Response**: `200 OK` — Session cookie (`Set-Cookie`) set automatically.

```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "User Name"
}
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Missing email or password |
| 401 | unauthorized | Invalid credentials (generic — no distinction between wrong password, non-existent user, locked, or deactivated account per CHK007; a deactivation notice email is sent to the account owner instead, AUD-06) |
| 403 | email_not_verified | Correct password but email not verified (AUD-04; only reachable with the correct password — no enumeration) |
| 429 | rate_limit_exceeded | Rate limit per email exceeded (5 req/min sliding window, FR-010) or per IP (20 req/min) |
| 503 | service_unavailable | Database unreachable |

**Rate Limit Headers** (on 429): `Retry-After`, `RateLimit-Reset`, `RateLimit-Remaining`

**Note (AUD-04)**: `email_not_verified` does NOT count toward the per-email lockout (FR-010).

---

## POST /api/auth/send-verification-email

Resend the email verification link (AUD-04). Always answers `{ "status": true }` regardless of whether the account exists or is already verified (anti-enumeration).

**Request Body**:

```json
{
  "email": "user@example.com"
}
```

**Success Response**: `200 OK`

```json
{ "status": true }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Invalid email format |
| 429 | rate_limit_exceeded | Rate limit per IP (20 req/min) or per email (5 req/min) |
| 503 | service_unavailable | Database unreachable |

---

## GET /api/auth/verify-email?token=...

Confirm email ownership by clicking the link from the email (AUD-04). The token is a signed JWT (1h expiry). Redirects to the origin (302) without any session state; unverified sessions from this browser are invalidated on success (better-auth behavior).

**Query Parameters**: `token` (required)

**Success Response**: `302 Found` → `Location: <origin>`

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 302 | — | `Location: <origin>?error=INVALID_TOKEN` — expired/forged token |

---

## POST /api/auth/forget-password

Request a password reset link (AUD-04). Always answers `{ "status": true }` regardless of whether the account exists (anti-enumeration).

**Request Body**:

```json
{
  "email": "user@example.com"
}
```

**Success Response**: `200 OK`

```json
{ "status": true }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Invalid email format |
| 429 | rate_limit_exceeded | Rate limit per IP (20 req/min) or per email (5 req/min) |
| 503 | service_unavailable | Database unreachable |

---

## POST /api/auth/reset-password

Set a new password with a single-use token from the forget-password email (AUD-04). Revokes all existing sessions (`revokeSessionsOnPasswordReset`). The token is accepted either in the body or the `token` query parameter (same validation, no double-consumption).

**Request Body**:

```json
{
  "token": "single-use-token",
  "newPassword": "new-secure-password-456"
}
```

**Success Response**: `200 OK`

```json
{ "status": true }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | invalid_token | Token invalid, expired, or already consumed (generic — indistinguishable) |
| 400 | validation_error | Missing token or invalid password (min 8 chars) |
| 429 | rate_limit_exceeded | Rate limit per IP (20 req/min) |
| 503 | service_unavailable | Database unreachable |

---

## GET /api/auth/reset-password/[token]

Click-time validation of the reset link, without consuming the token (AUD-04).

**Success Response**: `302 Found` → `Location: <origin>?token=<token>`

**Error Responses**: `302 Found` → `Location: <origin>?error=INVALID_TOKEN`

---

## POST /api/auth/logout

Terminate the current session (FR-006).

**Auth**: Required (session cookie)

**Success Response**: `200 OK`

```json
{ "message": "Logged out successfully" }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 401 | unauthorized | No active session |

---

## GET /api/auth/me

Return the currently authenticated user and active company context.

**Auth**: Required (session cookie)

**Success Response**: `200 OK`

```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "User Name",
  "activeCompanyId": "uuid-or-null",
  "companies": [{ "id": "uuid", "name": "Company Name", "role": "member" }]
}
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 401 | unauthorized | No active session |
| 401 | session_expired | Session past TTL (FR-023, `session_expired` event emitted) |

---

## POST /api/auth/companies

Create a new company. The requesting user becomes its first member (FR-014).

**Auth**: Required (session cookie)

**Request Body**:

```json
{
  "name": "Company Name",
  "cnpj": "XX.XXX.XXX/XXXX-XX",
  "razaoSocial": "Legal Name"
}
```

**Success Response**: `201 Created`

```json
{
  "id": "uuid",
  "name": "Company Name"
}
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Missing or invalid fields |
| 409 | conflict | CNPJ already registered |
| 503 | service_unavailable | Database unreachable |

---

## POST /api/auth/companies/join

Join an existing company by ID (FR-015).

**Auth**: Required (session cookie)

**Request Body**:

```json
{
  "companyId": "uuid"
}
```

**Success Response**: `200 OK`

```json
{ "message": "Joined company successfully" }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | Missing companyId |
| 404 | not_found | Company not found or deleted |
| 409 | conflict | User is already a member of this company |

---

## GET /api/auth/companies

Search for companies to join (FR-015).

**Auth**: Required (session cookie)

**Query Parameters**:

- `q` — search query (name or CNPJ partial match)

**Success Response**: `200 OK`

```json
{
  "companies": [{ "id": "uuid", "name": "Company Name", "cnpj": "XX.XXX.XXX/XXXX-XX" }]
}
```

---

## POST /api/auth/companies/switch

Switch the active company context for the current session.

**Auth**: Required (session cookie)

**Request Body**:

```json
{
  "companyId": "uuid"
}
```

**Success Response**: `200 OK`

```json
{ "message": "Active company switched" }
```

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 403 | forbidden | User is not a member of the specified company |
| 404 | not_found | Company not found or deleted |

---

## POST /api/auth/invite

Create an invite. Requires the caller to be an **owner** of the company.

**Auth**: Required (session cookie)

**Request Body**:

```json
{
  "companyId": "uuid",
  "email": "user@example.com"
}
```

**Success Response**: `201 Created`

```json
{
  "id": "uuid",
  "companyId": "uuid",
  "email": "user@example.com",
  "expiresAt": "2026-08-19T00:00:00Z",
  "token": "single-use-secret-token"
}
```

**Note (AUD-01)**: the `token` is returned **exactly once** — it is never
exposed again (`GET /invites` returns metadata only, without token). The token
expires after 7 days and is consumed on first successful accept.

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | `companyId` or `email` missing/invalid |
| 403 | forbidden | Caller is not a member or not an owner of the company |
| 404 | not_found | Company not found or deleted |
| 409 | conflict | Invite already exists for this company and email |

---

## POST /api/auth/invites/accept

Accept an invite by its secret token. Requires authentication; the invite
target email must match the **session email** (never the body).

**Auth**: Required (session cookie)

**Request Body**:

```json
{
  "token": "single-use-secret-token"
}
```

**Success Response**: `200 OK`

```json
{
  "id": "uuid",
  "companyId": "uuid",
  "acceptedAt": "2026-08-12T00:00:00Z"
}
```

**Note (AUD-01)**: token is single-use (accepted invites reject replays). All
failure modes (invalid, expired, consumed, wrong email) return the same
generic 404 — no enumeration.

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | `token` missing |
| 404 | not_found | Invite not found, expired, already consumed, or email mismatch |

---

## GET /api/auth/invites

List invites of a company.

**Auth**: Required (session cookie), caller must be a member of the company.

**Query Params**: `companyId` (required)

**Success Response**: `200 OK`

```json
{
  "invites": [
    {
      "id": "uuid",
      "companyId": "uuid",
      "email": "user@example.com",
      "invitedBy": "uuid",
      "acceptedAt": null,
      "expiresAt": "2026-08-19T00:00:00Z",
      "createdAt": "2026-08-12T00:00:00Z"
    }
  ]
}
```

**Note (AUD-01)**: invites never include the accept token.

**Error Responses**:
| Status | Error Code | Condition |
|--------|------------|-----------|
| 400 | validation_error | `companyId` missing |
| 403 | forbidden | Caller is not a member of the company |
| 404 | not_found | Company not found or deleted |

---

## CORS Configuration

- **Allowed Origin**: Explicit origin (e.g., `https://app.merp.com.br`) — no wildcard
- **Credentials**: `Access-Control-Allow-Credentials: true`
- **Methods**: GET, POST, OPTIONS
- **Preflight**: OPTIONS requests responded with appropriate CORS headers per FR-027
